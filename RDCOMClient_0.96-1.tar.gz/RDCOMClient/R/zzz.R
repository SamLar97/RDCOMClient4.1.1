.onLoad <-
function(lib, pkg) {
 #library.dynam("RDCOMClient", pkg, lib)
 .COMInit()
}


#.Last.lib <-
#function() {
#  gc()
#}



